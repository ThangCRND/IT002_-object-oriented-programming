#include<iostream>
#include"CTime.h"
using namespace std;

CTime::CTime(){
    this->Hour=this->Minute=this->second=0;
}
CTime::CTime(int h,int m,int s){
    this->Hour=h;
    this->Minute=m;
    this->second=s;
}
CTime::~CTime(){
}
int CTime::GetHour(){
    return this->Hour;
}
int CTime::GetMinute(){
    return this->Minute;
}
int CTime::GetSecond(){
        return this->second;
}
long CTime::GetTotalMinute(){
    return this->Minute+this->Hour*60;
}
long CTime::GetTotalSecond(){
    return this->second+this->Minute*60+this->Hour*60*60;
}
ostream& operator<<(ostream & os,CTime & Time){
    os<<Time.Hour<<"h"<<Time.Minute<<"m"<<Time.second<<"s";
    return os;
}
istream& operator>>(istream& is,CTime & Time){
    is>>Time.Hour>>Time.Minute>>Time.second;
}
void CTime::AddTime(CTime & T1,CTime & T2){
    this->Hour=(T1.GetTotalSecond()+T2.GetTotalSecond())/3600;
    this->Minute=(T1.GetTotalMinute()+T2.GetTotalMinute())%60;
    this->second=(T1.GetTotalSecond()+T2.GetTotalSecond())%60;
}
void CTime::SubTime(CTime & T1,CTime & T2){
    if(T1.GetTotalSecond()-T2.GetTotalSecond()<0){
        cout<<"Fail,negative time!"<<endl;
        return;
    }
    this->Hour=(T1.GetTotalSecond()-T2.GetTotalSecond())/3600;
    this->Minute=(T1.GetTotalMinute()-T2.GetTotalMinute())%60;
    this->second=(T1.GetTotalSecond()-T2.GetTotalSecond())%60;
}
void CTime::AddTimeSecond(int sec){
    this->second+=sec;
    this->Minute+=this->second/60;
    this->Hour+=this->Hour/60;
    this->Minute%=60;
    this->second%=60;
}
void CTime::SubTimeSecond(int sec){
        if(this->GetTotalSecond()-sec<0){
        cout<<"Fail,negative time!"<<endl;
        return;
    }
    int temp=(this->GetTotalSecond()-sec);
    this->Hour=(temp)/3600;
    this->Minute=(temp-3600*Hour)/60;
    this->second=temp%60;
}
void CTime::AddASecond(){
    this->AddTimeSecond(1);
}
void CTime::SubASecond(){
    this->SubTimeSecond(1);
}