#ifndef CTIME_H_
#define CTIME_H_
#include<iostream>
using namespace std;
class CTime
{
private:
    int Hour;
    int Minute;
    int second;
public:
    CTime();
    CTime(int h,int m,int s);
    ~CTime();
    int GetHour();
    int GetMinute();
    int GetSecond();
    long GetTotalMinute();
    long GetTotalSecond();
    friend ostream& operator<<(ostream & os,CTime & Time);
    friend istream& operator>>(istream& is,CTime & Time);
    void AddTime(CTime & T1,CTime & T2);
    void AddTimeSecond(int sec);
    void SubTime(CTime & T1,CTime & T2);
    void SubTimeSecond(int sec);
    void AddASecond();
    void SubASecond();
};
#endif