#include<iostream>
#include "CTime.h"
using namespace std;
int main(){
    CTime Time1;  //call default constructor
    CTime Time2(20,25,40);//call constructor
    cout<<"Time1 after constructor: "<<Time1<<", Time1 total second: "<<Time1.GetTotalSecond()<<endl;
    cout<<"Time2 after constructor: "<<Time2<<", Time2 total second: "<<Time2.GetTotalSecond()<<endl;
    cout<<"Set value to Time1: ";
    cin>>Time1;
    CTime SumTime;
    SumTime.AddTime(Time1,Time2);
    cout<<"Add Time1 "<<Time1<<" to Time2 "<<Time2<<" = "<<SumTime<<endl;
    CTime SubTime;
    SubTime.SubTime(Time1,Time2);
    cout<<"Sub Time1 "<<Time1<<" to Time2 "<<Time2<<" = "<<SubTime<<endl;
    Time1.AddASecond();
    cout<<"Add a second to Time1: "<<Time1<<endl;
    Time1.AddTimeSecond(300);
    cout<<"Add 300 second to Time1: "<<Time1<<endl;
    Time2.SubASecond();
    cout<<"Sub a second to Time2: "<<Time2<<endl;
    Time2.SubTimeSecond(300);
    cout<<"Sub 300 second to Time2: "<<Time2<<endl;
    return 0;
}