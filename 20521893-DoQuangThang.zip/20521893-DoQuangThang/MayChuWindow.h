#ifndef MAYCHUWINDOW_H_INCLUDED
#define MAYCHUWINDOW_H_INCLUDED

#include "MayChu.h"

class MaychuWD : public MayChu
{

public:
    MaychuWD();
    ~MaychuWD();

    void KhoiDongLai();
    void Nhap();
    void Xuat();
};



#endif // MAYCHUWINDOW_H_INCLUDED
