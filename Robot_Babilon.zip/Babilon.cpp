#include <iostream>
#include "Babilon.h"

using namespace std;

// Babilon
int Babilon::Babilon_MaxEnergy = 0;
string Babilon::Name_MaxEnergy = "";
int Babilon::SumEnergy = 0;

Babilon::Babilon()
{
    this->Weight = 0;
    this->distance = 0;
    this->name = "";
}

Babilon::Babilon(int w, double s, string name)
{
    this->Weight = w;
    this->distance = s;
    this->name = name;
}

inline string Babilon::GetName()
{
    return this->name;
}

inline void Babilon::SetDistance(double dis)
{
    this->distance = dis;
}

inline int Babilon::GetBabilon_MaxEnergy()
{
    return Babilon::Babilon_MaxEnergy;
}

inline string Babilon::GetName_MaxEngergy()
{
    return Babilon::Name_MaxEnergy;
}

inline int Babilon::GetEnergy_All()
{
    return Babilon::SumEnergy;
}

// Carrier
int Carrier::MaxEnergy = 0;

Carrier::Carrier() : Babilon(30, 0, "Carrier")
{
    this->E = 50;
    this->Energy = 0;
}

Carrier::Carrier(int e, double s) : Babilon(30, s, "Carrier")
{
    // input e
    if (e < 50)
    {
        this->E = 50;
    }
    else if (e > 100)
    {
        this->E = 100;
    }
    else
    {
        this->E = e;
    }

    // input energy
    SumEnergy -= Energy;
    this->Energy = Weight * distance + 4 * E * distance * 1.0;
    SumEnergy += Energy;
    if (MaxEnergy < Energy)
        MaxEnergy = Energy;
    if (Babilon_MaxEnergy < MaxEnergy)
    {
        Babilon_MaxEnergy = MaxEnergy;
        Name_MaxEnergy = this->name;
    }
}

inline double Carrier::GetEnergy()
{
    return this->Energy;
}

void Carrier::SetE(int e)
{
    // input e
    if (e < 50)
    {
        this->E = 50;
    }
    else if (e > 100)
    {
        this->E = 100;
    }
    else
    {
        this->E = e;
    }

    // input energy
    SumEnergy -= Energy;
    this->Energy = Weight * distance + 4 * E * distance * 1.0;
    SumEnergy += Energy;
    if (MaxEnergy < Energy)
        MaxEnergy = Energy;
    if (Babilon_MaxEnergy < MaxEnergy)
    {
        Babilon_MaxEnergy = MaxEnergy;
        Name_MaxEnergy = this->name;
    }
}

inline void Carrier::Print()
{
    cout << this->name << ": " << this->Energy << endl;
}

inline int Carrier::GetMaxEnergy()
{
    return Carrier::MaxEnergy;
}

// Pedion
int Pedion::MaxEnergy = 0;

Pedion::Pedion() : Babilon(20, 0, "Pedion")
{
    this->F = 1;
    this->Energy = 0;
}

Pedion::Pedion(int f, double s) : Babilon(20, s, "Pedion")
{
    // input F
    if (f < 1)
    {
        this->F = 1;
    }
    else if (f > 5)
    {
        this->F = 5;
    }
    else
    {
        this->F = f;
    }

    //input Energy
    SumEnergy -= Energy;
    this->Energy = Weight * distance + (F + 1) * distance / 2.0;
    SumEnergy += Energy;
    if (MaxEnergy < Energy)
        MaxEnergy = Energy;
    if (Babilon_MaxEnergy < MaxEnergy)
    {
        Babilon_MaxEnergy = MaxEnergy;
        Name_MaxEnergy = this->name;
    }
}

inline double Pedion::GetEnergy()
{
    return this->Energy;
}

void Pedion::SetF(int f)
{
    // input F
    if (f < 1)
    {
        this->F = 1;
    }
    else if (f > 5)
    {
        this->F = 5;
    }
    else
    {
        this->F = f;
    }

    //input Energy
    SumEnergy -= Energy;
    this->Energy = this->Weight * this->distance + (this->F + 1) * this->distance / 2.0;
    SumEnergy += Energy;
    if (MaxEnergy < Energy)
        MaxEnergy = Energy;
    if (Babilon_MaxEnergy < MaxEnergy)
    {
        Babilon_MaxEnergy = MaxEnergy;
        Name_MaxEnergy = this->name;
    }
}

inline void Pedion::Print()
{
    cout << this->name << ": " << this->Energy << endl;
}

inline int Pedion::GetMaxEnergy()
{
    return Pedion::MaxEnergy;
}

// Zattacker
int Zattacker::MaxEnergy = 0;

Zattacker::Zattacker() : Babilon(50, 0, "Zattacker")
{
    this->P = 20;
    this->Energy = 0;
}

Zattacker::Zattacker(int p, double s) : Babilon(50, s, "Zattacker")
{
    // input P
    if (p < 20)
    {
        this->P = 20;
    }
    else if (p > 30)
    {
        this->P = 30;
    }
    else
    {
        this->P = p;
    }

    //input Energy
    SumEnergy -= Energy;
    this->Energy = Weight * distance + P * P * distance * 1.0;
    SumEnergy += Energy;
    if (MaxEnergy < Energy)
        MaxEnergy = Energy;
    if (Babilon_MaxEnergy < MaxEnergy)
    {
        Babilon_MaxEnergy = MaxEnergy;
        Name_MaxEnergy = this->name;
    }
}

inline double Zattacker::GetEnergy()
{
    return this->Energy;
}

void Zattacker::SetP(int p)
{
    // input P
    if (p < 20)
    {
        this->P = 20;
    }
    else if (p > 30)
    {
        this->P = 30;
    }
    else
    {
        this->P = p;
    }

    //input Energy
    SumEnergy -= Energy;
    this->Energy = Weight * distance + P * P * distance * 1.0;
    SumEnergy += Energy;
    if (MaxEnergy < Energy)
        MaxEnergy = Energy;
    if (Babilon_MaxEnergy < MaxEnergy)
    {
        Babilon_MaxEnergy = MaxEnergy;
        Name_MaxEnergy = this->name;
    }
}

inline void Zattacker::Print()
{
    cout << this->name << ": " << this->Energy << endl;
}

inline int Zattacker::GetMaxEnergy()
{
    return Zattacker::MaxEnergy;
}
