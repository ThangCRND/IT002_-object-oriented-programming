#ifndef BABILON_H_INCLUDED
#define BABILON_H_INCLUDED
#include <string>

using namespace std;

class Babilon
{
protected:
    double Weight, distance;
    string name;
    static int Babilon_MaxEnergy;
    static string Name_MaxEnergy;
    static int SumEnergy;

public:
    Babilon();
    Babilon(int, double, string);
    ~Babilon() {}
    string GetName();
    void SetDistance(double dis);
    int GetBabilon_MaxEnergy();
    string GetName_MaxEngergy();
    int GetEnergy_All();
};

class Carrier : public Babilon
{
private:
    int E;
    double Energy;
    static int MaxEnergy;

public:
    Carrier();
    Carrier(int e, double s);
    ~Carrier() {}
    double GetEnergy();
    void SetE(int e);
    void Print();
    int GetMaxEnergy();
};

class Zattacker : public Babilon
{
private:
    int P;
    double Energy;
    static int MaxEnergy;

public:
    Zattacker();
    Zattacker(int p, double s);
    ~Zattacker() {}
    double GetEnergy();
    void SetP(int p);
    void Print();
    int GetMaxEnergy();
};

class Pedion : public Babilon
{
private:
    int F;
    double Energy;
    static int MaxEnergy;

public:
    Pedion();
    Pedion(int f, double s);
    ~Pedion() {}
    double GetEnergy();
    void SetF(int F);
    void Print();
    int GetMaxEnergy();
};

#endif