#include <iostream>
#include "Babilon.cpp"
#include <ctime>
#include <cstdlib>

using namespace std;

int main()
{
    int A, B, C;
    cout << "Nhap so luong Pedion: ";
    cin >> A;
    cout << "Nhap so luong Zattacker: ";
    cin >> B;
    cout << "Nhap so luong Carrier: ";
    cin >> C;

    srand(time(NULL));
    Pedion *PE = new Pedion[A];
    for (int i = 0; i < A; i++)
    {
        PE[i].SetDistance(10);
        int temp = rand() % (6 - 1) + 1;
        PE[i].SetF(temp);
    }

    for (int i = 0; i < A; i++)
    {
        PE[i].Print();
    }

    srand(time(NULL));
    Zattacker *ZA = new Zattacker[B];
    for (int i = 0; i < B; i++)
    {
        ZA[i].SetDistance(10);
        int temp = rand() % (31 - 20) + 20;
        ZA[i].SetP(temp);
    }

    for (int i = 0; i < A; i++)
    {
        ZA[i].Print();
    }

    srand(time(NULL));
    Carrier *CA = new Carrier[C];
    for (int i = 0; i < C; i++)
    {
        CA[i].SetDistance(10);
        int temp = rand() % (101 - 50) + 50;
        CA[i].SetE(temp);
    }

    for (int i = 0; i < C; i++)
    {
        CA[i].Print();
    }

    cout << "Max Energy Pedion: " << PE->GetMaxEnergy() << endl;
    cout << "Max Energy Zattacker: " << ZA->GetMaxEnergy() << endl;
    cout << "Max Energy Carrier: " << CA->GetMaxEnergy() << endl;

    cout << "Max Energy Babilon: " << PE->GetName_MaxEngergy() << ": " << PE->GetBabilon_MaxEnergy() << endl;

    cout << "tong nang luong toan ham doi: " << PE->GetEnergy_All() << endl;

    return 0;
}