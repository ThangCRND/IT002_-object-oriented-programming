#pragma once
#include<vector>
using namespace std;
struct Coordinate
{
    int x;
    int y;
};

class Polygons
{
private:
    int NumVertices;
    vector<Coordinate> Coor;
public:
    //Constructor and Destructor
    Polygons();
    Polygons(int num);
    virtual ~Polygons();
    //Setter
    void SetNumVertices(int num);
    void SetCoor(vector<Coordinate> coor);
    virtual void Set();
    //Getter
    int GetNumVertices(){return NumVertices;}
    vector<Coordinate> GetCoor(){return Coor;}
    //other method
    virtual void Print();
    virtual bool Check();
    void Move(int x,int y);
};
class Quadrangle:public Polygons
{
private:
    const int Vertices=4;

public:
    //constructor and destructor
    Quadrangle();
    virtual ~Quadrangle();
    //Setter
    void Set();
    //other methods
    void Print();
};
class Triangle final:public Polygons
{
private:
    const int Vertices=3;

public:
    //constructor and destructor
    Triangle();
    ~Triangle();
    //Setter
    void Set();
    //other methods
    void Print();
};
class Parallelogram final :public Quadrangle
{
public:
    //Constructor and Destructor
    Parallelogram();
    ~Parallelogram();
    //Setter
    void Set();
    //other method
    bool Check();
    void Print();
};
class RectAngle:public Quadrangle
{
public:
    //Constructor and Destructor
    RectAngle();
    virtual ~RectAngle();
    //Setter
    void Set();
    //other method
    bool Check();
    virtual void Print();
};
class Square final :public RectAngle
{
public:
    //Constructor and Destructor
    Square();
    ~Square();
    //Setter
    void Set();
    //other method
    bool Check();
    void Print();
};
