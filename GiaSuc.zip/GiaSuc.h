#ifndef GIASUC_H_INCLUDED
#define GIASUC_H_INCLUDED
#include <iostream>
using namespace std;

class GiaSuc
{
protected:
    string AmThanh;
    int Sua;
    static int SLGrowUp;
    static int SLYoung;
public:
    GiaSuc();
    ~GiaSuc() {}
    string GetAmThanh();
    int GetSua();
    void SetAmThanh(string);
    void SetSua(int);
    int GetGrowUpAll();
    int GetYoungAll();
    virtual void Birth()
    {
        this->SLYoung++;
    }
};

class Bo:public GiaSuc
{
    static int SLGrowUp_Bo;
    static int SLYoung_Bo;
public:
    Bo();
    ~Bo() {}
    void Birth();
    int GetGrowUp();
    int GetYoung();
};

class Cuu:public GiaSuc
{
    static int SLGrowUp_Cuu;
    static int SLYoung_Cuu;
public:
    Cuu();
    ~Cuu() {}
    void Birth();
    int GetGrowUp();
    int GetYoung();
};

class De:public GiaSuc
{
    static int SLGrowUp_De;
    static int SLYoung_De;
public:
    De();
    ~De() {}
    void Birth();
    int GetGrowUp();
    int GetYoung();
};


#endif // GIASUC_H_INCLUDED
