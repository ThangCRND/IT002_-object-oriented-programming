#include <iostream>
#include "GiaSuc.cpp"

using namespace std;

int main()
{
    int SLBo, SLCuu, SLDe;
    cout << "Nhap so luong bo: ";
    cin >> SLBo;
    cout << "Nhap so Luong cuu: ";
    cin >> SLCuu;
    cout << "Nhap so luong de: ";
    cin >> SLDe;
    Bo *Bos = new Bo[SLBo];
    Cuu *Cuus = new Cuu[SLCuu];
    De *Des = new De[SLDe];

    // Tieng keu
    cout << "\nCon bo keu: " << Bos[0].GetAmThanh();
    cout << "\nCon cuu keu: " << Cuus[0].GetAmThanh();
    cout << "\nCon De keu: " << Des[0].GetAmThanh();
    cout << endl;

    // Sinh san va cho sua
    int SLSua_Bo=0;
    for (int i=0; i<SLBo; i++)
    {
        Bos[i].Birth();
        SLSua_Bo+=Bos[i].GetSua();
    }

    int SLSua_Cuu=0;
    for (int i=0; i<SLCuu; i++)
    {
        Cuus[i].Birth();
        SLSua_Cuu+=Cuus[i].GetSua();
    }

    int SLSua_De=0;
    for (int i=0; i<SLDe; i++)
    {
        Des[i].Birth();
        SLSua_De+=Des[i].GetSua();
    }

    // so luong sinh san va tong so luong sua
    cout << "\nThong tin bo:";
    cout << "\nSo luong bo truong thanh: " << Bos[0].GetGrowUp();
    cout << "\nSo luong bo moi sinh: " << Bos[0].GetYoung();
    cout << "\nSo luong sua bo: " << SLSua_Bo;
    cout << endl;

    cout << "\nThong tin cuu:";
    cout << "\nSo luong cuu truong thanh: " << Cuus[0].GetGrowUp();
    cout << "\nSo luong cuu moi sinh: " << Cuus[0].GetYoung();
    cout << "\nSo luong sua cuu: " << SLSua_Cuu;
    cout << endl;

    cout << "\nThong tin de:";
    cout << "\nSo luong de truong thanh: " << Des[0].GetGrowUp();
    cout << "\nSo luong de moi sinh: " << Des[0].GetYoung();
    cout << "\nSo luong sua de: " << SLSua_De;
    cout << endl;

    GiaSuc GS;
    cout << "\nThong tin trang trai:";
    cout << "\nSo luong gia suc truong thanh: " << GS.GetGrowUpAll()-1;
    cout << "\nSo luong gia suc moi sinh: " << GS.GetYoungAll();
    cout << endl;

    return 0;
}
