#include "GiaSuc.h"
#include <ctime>
#include <cstdlib>

using namespace std;

// Gia Suc
int GiaSuc::SLGrowUp=0;

int GiaSuc::SLYoung=0;

GiaSuc::GiaSuc()
{
    this->AmThanh="";
    this->Sua=0;
    this->SLGrowUp++;
}

inline string GiaSuc::GetAmThanh()
{
    return this->AmThanh;
}

inline int GiaSuc::GetSua()
{
    return this->Sua;
}

inline void GiaSuc::SetAmThanh(string AmThanh)
{
    this->AmThanh=AmThanh;
}

inline void GiaSuc::SetSua(int Sua)
{
    this->Sua=Sua;
}

inline int GiaSuc::GetGrowUpAll()
{
    return this->SLGrowUp;
}

inline int GiaSuc::GetYoungAll()
{
    return this->SLYoung;
}

// Bo
int Bo::SLGrowUp_Bo=0;

int Bo::SLYoung_Bo=0;

Bo::Bo():GiaSuc()
{
    this->AmThanh="Moo...";
    srand(time(NULL));
    this->Sua = (rand() % 20 + 1);
    this->SLGrowUp_Bo++;
}

 inline void Bo::Birth()
{
    this->SLYoung_Bo++;
    this->SLYoung++;
}

inline int Bo::GetGrowUp()
{
    return this->SLGrowUp_Bo;
}

inline int Bo::GetYoung()
{
    return this->SLYoung_Bo;
}


// Cuu
int Cuu::SLGrowUp_Cuu=0;

int Cuu::SLYoung_Cuu=0;

Cuu::Cuu():GiaSuc()
{
    this->AmThanh="Bee...";
    srand(time(NULL));
    this->Sua = (rand()%5+1);
    this->SLGrowUp_Cuu++;
}

 inline void Cuu::Birth()
{
    this->SLYoung_Cuu++;
    this->SLYoung++;
}

inline int Cuu::GetGrowUp()
{
    return this->SLGrowUp_Cuu;
}

inline int Cuu::GetYoung()
{
    return this->SLYoung_Cuu;
}

// De
int De::SLGrowUp_De=0;

int De::SLYoung_De=0;

De::De():GiaSuc()
{
    this->AmThanh="Maa...";
    srand(time(NULL));
    this->Sua = (rand()%10+1);
    this->SLGrowUp_De++;
}

 inline void De::Birth()
{
    this->SLYoung_De++;
    this->SLYoung++;
}

inline int De::GetGrowUp()
{
    return this->SLGrowUp_De;
}

inline int De::GetYoung()
{
    return this->SLYoung_De;
}
