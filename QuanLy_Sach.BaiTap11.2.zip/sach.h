#ifndef SACH_H
#define SACH_H


class Sach
{
protected:
    char Ten[20];
    char NXB[20];
    int NamXb;
    int SoTrang;
    int GiaBan;
public:
    Sach();
    ~Sach();
    virtual void Nhap();
    virtual void Xuat();
};

#endif // SACH_H
