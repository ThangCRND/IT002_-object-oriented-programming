#ifndef TAPCHI_H
#define TAPCHI_H
#include "sach.h"

class TapChi:public Sach
{
protected:
    char DangTapChi[20];
public:
    TapChi();
    ~TapChi();
    void Nhap();
    void Xuat();
};

#endif // TAPCHI_H
