#include "tieuthuyet.h"
#include "sach.h"
#include <iostream>
using namespace std;
TieuThuyet::TieuThuyet()
{
    //ctor
}

TieuThuyet::~TieuThuyet()
{
    //dtor
}

void TieuThuyet::Nhap()
{
    cout<<"The loai: ";
    gets(TheLoai);
    Sach::Nhap();
}

void TieuThuyet::Xuat()
{
    cout<<"The loai: Tieu thuyet"<<endl;
    cout<<"The loai: "<<TheLoai<<endl;
    Sach::Xuat();
}
