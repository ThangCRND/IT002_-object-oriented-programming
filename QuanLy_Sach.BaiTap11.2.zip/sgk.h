#ifndef SGK_H
#define SGK_H
#include "sach.h"

class SGK:public Sach
{
protected:
    int KhoiHoc;
public:
    SGK();
    ~SGK();
    void Nhap();
    void Xuat();
};

#endif // SGK_H
