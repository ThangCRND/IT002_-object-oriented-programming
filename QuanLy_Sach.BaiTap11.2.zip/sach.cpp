#include "sach.h"
#include <iostream>
using namespace std;
Sach::Sach()
{
    //ctor
}

Sach::~Sach()
{
    //dtor
}

void Sach::Nhap()
{
    cout<<"Ten: ";
    gets(Ten);
    cout<<"Nha xuat ban: ";
    gets(NXB);
    cout<<"Nam xuat ban: ";
    cin>>NamXb;
    cout<<"So trang: ";
    cin>>SoTrang;
    cout<<"Gia ban: ";
    cin>>GiaBan;
    cin.ignore();
}

void Sach::Xuat()
{
    cout<<"Ten: "<<Ten<<endl;
    cout<<"Nha xuat ban: "<<NXB<<endl;
    cout<<"Nam xuat ban: "<<NamXb<<endl;
    cout<<"So trang: "<<SoTrang<<endl;
    cout<<"Gia: "<<GiaBan<<endl;
}
