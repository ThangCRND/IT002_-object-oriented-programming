#include "tapchi.h"
#include "sach.h"
#include <iostream>
using namespace std;
TapChi::TapChi()
{
    //ctor
}

TapChi::~TapChi()
{
    //dtor
}

void TapChi::Nhap()
{
    cout<<"Dang tap chi: ";
    gets(DangTapChi);
    Sach::Nhap();
}

void TapChi::Xuat()
{
    cout<<"The loai: Tap chi"<<endl;
    cout<<"Dang tap chi: "<<DangTapChi<<endl;
    Sach::Xuat();
}
