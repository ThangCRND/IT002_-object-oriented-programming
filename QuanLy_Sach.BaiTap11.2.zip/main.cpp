#include <vector>
#include <iostream>
#include "sach.h"
#include "sgk.h"
#include "tieuthuyet.h"
#include "tapchi.h"
#define MAX 400
using namespace std;

void NhapDs(vector<Sach*> &DanhSach)
{
    int luachon;
    do
    {
        cout<<"<1> Nhap thong tin sach giao khoa."<<endl;
        cout<<"<2> Nhap thong tin tieu thuyet."<<endl;
        cout<<"<3> Nhap thong tin tap chi."<<endl;
        cout<<"<4> Quay ve Menu ban dau."<<endl;
        cout<<"Nhap lua chon cua ban: ";
        cin>>luachon;
        while(luachon<1||luachon>4)
        {
            cout<<"Lua chon khong ton tai, vui long nhap lai: ";
            cin>>luachon;
            cin.ignore();
        }
        switch(luachon)
        {
        case 1:
            DanhSach.push_back(new SGK);
            DanhSach[DanhSach.size()-1]->Nhap();
            break;
        case 2:
            DanhSach.push_back(new TieuThuyet);
            cin.ignore();
            DanhSach[DanhSach.size()-1]->Nhap();
            break;
        case 3:
            DanhSach.push_back(new TapChi);
            cin.ignore();
            DanhSach[DanhSach.size()-1]->Nhap();
            break;
        default:
            break;
        }
    }while(luachon!=4);
}

void XuatDs(vector<Sach*> DanhSach)
{
    cout<<"Danh sach cac loai sach vua nhap: "<<endl;
    for(int i=0; i<DanhSach.size(); i++)
    {
        DanhSach[i]->Xuat();
        cout<<endl;
    }
}

int main()
{
    vector<Sach*> DanhSach;
    int yeucau;
    do
    {
        cout<<"Chuong trinh quan li sach."<<endl;
        cout<<"<1> Nhap danh sach sach."<<endl;
        cout<<"<2> Xuat danh sach sach."<<endl;
        cout<<"<3> Thoat khoi chuong trinh."<<endl;
        cout<<"Nhap yeu cau ban muon thuc hien: ";
        cin>>yeucau;
        while(yeucau<1||yeucau>3)
        {
            cout<<"Yeu cau cua ban khong ton tai, vui long nhap lai: ";
            cin>>yeucau;
        }
        switch(yeucau)
        {
        case 1:
            NhapDs(DanhSach);
            break;
        case 2:
            XuatDs(DanhSach);
            break;
        default:
            break;
        }
    }while(yeucau!=3);
    return 0;
}
