#ifndef TIEUTHUYET_H
#define TIEUTHUYET_H
#include "sach.h"

class TieuThuyet:public Sach
{
protected:
    char TheLoai[20];
public:
    TieuThuyet();
    ~TieuThuyet();
    void Nhap();
    void Xuat();
};

#endif // TIEUTHUYET_H
