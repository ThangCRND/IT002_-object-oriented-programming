#include "sgk.h"
#include "sach.h"
#include <iostream>
using namespace std;
SGK::SGK()
{
    //ctor
}

SGK::~SGK()
{
    //dtor
}

void SGK::Nhap()
{
   cout<<"Khoi hoc: ";
   cin>>KhoiHoc;
   cin.ignore();
   Sach::Nhap();
}

void SGK::Xuat()
{
    cout<<"The loai: Sach giao khoa"<<endl;
    cout<<"Khoi hoc: "<<KhoiHoc<<endl;
    Sach::Xuat();
}
