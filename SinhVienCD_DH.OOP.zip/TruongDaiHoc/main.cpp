#include "TruongDaiHoc.hpp"
#include "HeDaiHoc.hpp"
#include "HeCaoDang.hpp"
#include <iostream>


int main(int argc, const char * argv[]) {
    
// Cau 1
    int n,m;
    cout << "nhap so luong sinh vien he dai hoc: ";
    cin >> n; cout << endl;
    HeDaiHoc *dh = new HeDaiHoc[n];
    

    for(int i = 0; i < n; i++)
    {
        cout << "\nSinh vien thu " << i + 1 << " :" << endl;
        dh[i].nhap();
    }
    
    cout << "nhap so luong sinh vien he cao dang: ";
    cin >> m; cout << endl;
    HeCaoDang *cd = new HeCaoDang[m];

    for(int i = 0; i < m; i++)
    {
        cout << "\nSinh vien thu " << i + 1 << " :" << endl;
        cd[i].nhap();
    }
    
 // Cau 2
    for(int i = 0; i < n; i++)
    {
        dh[i].xetTotNghiep();
    }
    for(int i = 0; i < m; i++)
    {
        cd[i].xetTotNghiep();
    }
    int count = TruongDaiHoc::dem;
    cout << "So sinh vien du dieu kien tot nghiep: " << count << endl;
    
// cau 3
// tim sinh vien he dai hoc diem cao nhat
    cout << endl;
    HeDaiHoc max1 = dh[0];
    for(int i = 1; i < n; i++)
    {
        if(dh[1].getDiemTrungBinh() > max1.getDiemTrungBinh())
            max1 = dh[1];
    }
    
    HeCaoDang max2 = cd[0];
    for(int i = 1; i < m; i++)
    {
        if(cd[1].getDiemTrungBinh() > max2.getDiemTrungBinh())
            max2 = cd[1];
    }
    
    cout << "Sinh vien he dai hoc cao diem nhat: \n";
    max1.xuat();
    
    cout << endl;
    cout << "Sinh vien he cao dang cao diem nhat: \n";
    max2.xuat();
    
    return 0;
}
